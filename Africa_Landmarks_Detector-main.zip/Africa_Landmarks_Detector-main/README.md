# World_Landmarks_Detector
AI Model powered by TensorFlow and run with python 
Try it out with StreamLit cloud
https://africalandmarksdetector-21egjx3ytum.streamlit.app
